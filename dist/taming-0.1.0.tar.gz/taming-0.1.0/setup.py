# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['taming',
 'taming.data',
 'taming.data.conditional_builder',
 'taming.models',
 'taming.modules',
 'taming.modules.diffusionmodules',
 'taming.modules.discriminator',
 'taming.modules.losses',
 'taming.modules.misc',
 'taming.modules.transformer',
 'taming.modules.vqvae']

package_data = \
{'': ['*']}

install_requires = \
['albumentations>=0.4.3,<0.5.0',
 'einops>=0.3.0,<0.4.0',
 'imageio-ffmpeg>=0.4.2,<0.5.0',
 'imageio>=2.9.0,<3.0.0',
 'more-itertools>=8.0.0,<9.0.0',
 'numpy>=1.21.5,<2.0.0',
 'omegaconf>=2.0.0,<3.0.0',
 'opencv-python>=4.1.2.30,<5.0.0.0',
 'pytorch-lightning>=1.0.8,<2.0.0',
 'streamlit>=0.73.1,<0.74.0',
 'test-tube>=0.7.5,<0.8.0',
 'torch==1.10.0',
 'torchvision==0.11.1',
 'transformers>=4.16.2,<5.0.0']

setup_kwargs = {
    'name': 'taming',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Egle Grublyte',
    'author_email': 'egle.grublyte@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
